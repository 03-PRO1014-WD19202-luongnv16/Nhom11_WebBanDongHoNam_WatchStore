<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 8.4.0 in which this polyfill is not needed.
 */
trait ExpectPHPException {}
