<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 5.2.0 in which this polyfill is not needed.
 */
trait ExpectException {}
