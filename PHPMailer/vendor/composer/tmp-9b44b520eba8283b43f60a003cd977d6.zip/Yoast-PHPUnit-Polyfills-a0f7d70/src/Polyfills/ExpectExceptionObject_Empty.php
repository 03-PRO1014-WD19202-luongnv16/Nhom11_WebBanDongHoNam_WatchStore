<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 6.4.0 in which this polyfill is not needed.
 */
trait ExpectExceptionObject {}
