<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 7.5.0 in which this polyfill is not needed.
 */
trait AssertStringContains {}
