<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 9.1.0 in which this polyfill is not needed.
 */
trait AssertionRenames {}
