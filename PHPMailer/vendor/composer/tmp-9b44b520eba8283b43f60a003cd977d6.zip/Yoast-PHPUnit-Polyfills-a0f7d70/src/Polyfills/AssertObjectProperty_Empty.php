<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 9.6.11 in which this polyfill is not needed.
 *
 * @since 1.1.0
 */
trait AssertObjectProperty {}
