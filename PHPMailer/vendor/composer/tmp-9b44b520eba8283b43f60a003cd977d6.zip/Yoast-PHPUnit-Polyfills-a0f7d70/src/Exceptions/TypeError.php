<?php

/**
 * Polyfill the PHP 7.0+ native TypeError class.
 *
 * @phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace
 */
class TypeError extends Error {}
