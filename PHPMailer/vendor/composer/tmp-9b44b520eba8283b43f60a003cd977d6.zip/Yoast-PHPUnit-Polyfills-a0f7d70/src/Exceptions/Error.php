<?php

/**
 * Polyfill the PHP 7.0+ native Error class.
 *
 * @phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace
 */
class Error extends Exception {}
